<br/>
<p align="center">
  <a href="https://github.com/aaryavbehl/depressionwebsite">
    <img src="https://imgs.search.brave.com/s_ypLYaeq0T3E_op8hXwNGlxBFYM0ZGl3EKehHGJ4A4/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9pLnBp/bmltZy5jb20vb3Jp/Z2luYWxzLzdiLzJh/LzVmLzdiMmE1ZmY1/MDU0YWE3ZmZjZTNi/OTdmMDY2NjdjOWI4/LS1naWYtZ2lmLXJh/aW5ib3ctY29ubmVj/dGlvbi5qcGc" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">WEBSITE</h3>

  <p align="center">
    A website to spread awareness of depression
    <br/>
    <br/>
  </p>
</p>

![Forks](https://img.shields.io/github/forks/aaryavbehl/depressionwebsite?style=social) ![Stargazers](https://img.shields.io/github/stars/aaryavbehl/depressionwebsite?style=social) 

## About The Project

This project was mainly made for the Artificial Intelligence Practical Activity.

## Built With

The Website is built with HTML, CSS and Bootstrap

## Getting Started

To deploy the website on your own, you will have to download the git repo.

### Prerequisites

Any platform device that can connect and view website

Recommended: Any PC

### Installation

1. Clone the repo.

2. Open the .html file.

3. Voilla!

`You can open the full website project in your preferred code editor to modify the website.`

## Usage

Main purpose of this website is to spread awareness and knowledge regarding depression.





## Authors

* **Aaryav Behl** - *Hobbyist* - [Aaryav Behl](https://aaryav.netlify.app/) - *Built the website + Backend*
